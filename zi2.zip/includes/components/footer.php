<?php
/**
 * File: footer.php
 * Main footer component
 */
?>
        </div> <!-- /container -->
        
        <!-- اسکریپت‌ها -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>
        <script type="module" src="assets/js/main.js"></script>
    </body>
</html>